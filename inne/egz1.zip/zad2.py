from zad2testy import runtests


def robot( L, A, B ):
    """tu prosze wpisac wlasna implementacje"""
    return 0

    
runtests( robot )


