from zad1testy import runtests


def chaos_index( T ):
    # tu prosze wpisac wlasna implementacje
    return None


runtests( chaos_index )
