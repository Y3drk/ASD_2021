from zad3testy import runtests


def kintersect( A, k ):
  """Miejsce na Twoją implementację"""
  return list(range(k))

runtests( kintersect )